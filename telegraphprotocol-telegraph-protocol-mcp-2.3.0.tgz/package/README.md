# Telegraph MCP server

> **Just want your agent to use Anjoman for outside intelligence?** Install the [`anjoman` skill](skills/anjoman/SKILL.md) instead: `npx skills add telegraphprotocol/telegraph-mcp --skill anjoman`, then set `ANJOMAN_API_KEY`. No MCP server or wallet, and it supports follow-ups, a spend cap, progress, traces and receipts. This MCP server is for direct specialist access.

Gives any MCP agent (Claude Desktop, Claude Code, Cursor, Continue, Goose, OpenClaw, LangChain, ElizaOS, ...) the Telegraph network, on your own computer. Ask a question and the best-ranked miner answers. Payment comes from your Telegraph escrow automatically: no keys, signatures or blockchain steps for you or your agent.

## Start in three steps

You need Node 20 or later.

**1. Set up once.** In a terminal:

```bash
npx -y @telegraphprotocol/telegraph-protocol-mcp setup
```

It checks the network and creates a wallet just for Telegraph. You can import a key instead. The wallet is saved to `~/.telegraph/wallet.json`, readable only by you. Setup then shows the address and balances, moves the USDC you choose into escrow after you confirm, and offers to add Telegraph to your agent app.

**2. Restart your agent app.**

**3. Ask it something:** "What is the BTC price? Use Telegraph." Every ask after that is paid from escrow on its own.

Top up any time with `npx -y @telegraphprotocol/telegraph-protocol-mcp fund`. Check balances with `... status`.
Take USDC back out with `... withdraw`: it requests the amount, and you run it again to collect once a ledger root covers the request.

Back up `~/.telegraph/wallet.json`. It is the only copy of the key, and the escrow balance goes with it.

## Adding it to an app by hand

No setting or key is needed: the server uses the wallet from setup. `setup` and `install <app>` write these for you where they can.

| App | How |
|---|---|
| Claude Code | `claude mcp add --scope user telegraph -- npx -y @telegraphprotocol/telegraph-protocol-mcp` |
| Claude Desktop, Cursor, any other MCP client | Add to `mcpServers`: `{"telegraph": {"command": "npx", "args": ["-y", "@telegraphprotocol/telegraph-protocol-mcp"]}}` |
| OpenClaw | `openclaw mcp add telegraph --command npx --arg=-y --arg @telegraphprotocol/telegraph-protocol-mcp` |
| Continue, Goose, LangChain, ElizaOS | Ready files in [examples/](examples/) |

## How paying works

- **The MCP server is your wallet.** It runs on your machine, loads the key from `~/.telegraph/wallet.json` (or `TELEGRAPH_PRIVATE_KEY`), and calls the node's `/engine/v1/ask` itself. When the node asks for payment, the server signs the escrow authorization with that key and sends the ask again. The agent never sees the key or the signature.
- **Escrow, always, by default.** You deposit USDC once. The escrow signature proves you asked, but it can't move funds. Asks are charged in the epoch's ledger root, and **a failed ask is never billed**.
- **Multi-miner asks.** `telegraph_ask` sends `max_budget_usdc` (default 260000 μUSDC, $0.26, the most the testnet node takes). When the first miner's answer misses part of the question, the node asks the next ranked miners for the rest within that budget. Escrow holds the budget while the ask runs; only the miners whose answers are used are billed, and the rest is released. The reply's `fulfillment` says whether the answer is complete, who gave each field, and the payments.
- **When escrow runs low,** the ask is refused with a message saying how much is left and how to top up. Nothing is charged, and the wallet is never paid from silently.
- **No double charges.** Repeating the same ask within a minute, or while it's still running, returns that answer, not a second charge.
- **Limits.** The server won't pay more than $0.50 for one ask or $5 a day. Change them with the settings below.
- **x402** (paying each ask straight from the wallet's USDC) is still there, but only if you turn it on: `TELEGRAPH_PAYMENT=auto` for escrow then x402, or `x402` for x402 only.

Details and withdrawing: [guides/2-payments.md](guides/2-payments.md).

## Settings

All optional.

| Variable | Default | What it is |
|---|---|---|
| `TELEGRAPH_PAYMENT` | `escrow` | `escrow`; `auto` (escrow, then x402); `x402` |
| `TELEGRAPH_MAX_ASK_USD` | `0.5` | The most one ask may cost. `0` means no limit |
| `TELEGRAPH_DAILY_LIMIT_USD` | `5` | The most all asks may cost in a UTC day. `0` means no limit |
| `TELEGRAPH_MAX_BUDGET_USDC` | `260000` | `max_budget_usdc` for each `telegraph_ask`, in μUSDC, the first call included (never above `TELEGRAPH_MAX_ASK_USD`). `0` sends none: one miner, nothing recovered |
| `TELEGRAPH_HOME` | `~/.telegraph` | Where the wallet and the day's spending are kept |
| `TELEGRAPH_PRIVATE_KEY` | none | Use this key instead of the wallet file. For servers and CI. (`TELEGRAPH_EVM_PRIVATE_KEY`, the v1 name, also works.) |
| `TELEGRAPH_API_KEY` | none | An Anjoman API key (`anjoman_…`). Switches to [key mode](#using-an-api-key-instead-of-a-wallet): no wallet is used |
| `TELEGRAPH_API_URL` | `https://backend.telegraphprotocol.com` | Where the API key is used |
| `TELEGRAPH_KEY_PAYMENT` | `escrow` | Key mode: how the account pays unless a call sets `payment`. `escrow`; `solana` (x402 from the account's Solana address); `evm` (x402 from its EVM address, wallet-connected accounts only) |
| `TELEGRAPH_ALLOW_AGENT_DEPOSIT` | off | Also give the agent a `telegraph_deposit` tool |
| `TELEGRAPH_URL` | `https://devnode.telegraphprotocol.com` | The node (the Telegraph testnet) |
| `TELEGRAPH_RPC_URL`, `TELEGRAPH_DIAMOND`, `TELEGRAPH_CHAIN_ID` | the testnet's (diamond `0x72a70e949362670Bf8bceAd24eFC5b8f950aa08b`) | The chain and the contract that holds escrow |

## Using an API key instead of a wallet

If you have an Anjoman account, you can skip the wallet. Create a key on the **API keys** page (`https://anjoman.ai/dashboard/api-keys`), deposit into your account there, and set it in your agent's settings:

```json
{"mcpServers": {"telegraph": {"command": "npx", "args": ["-y", "@telegraphprotocol/telegraph-protocol-mcp"], "env": {"TELEGRAPH_API_KEY": "anjoman_your_key_here"}}}}
```

No `setup` is needed. In key mode:

- `telegraph_ask` is a multi-miner call through your Anjoman account's agent: it splits the request across intents and miners, combines their answers and writes one reply. A question can take up to a minute.
- `telegraph_ask_auto` is the node's auto-routed ask, without the agent: the node picks the top live miner and asks the next ones for what it missed. It holds a budget of $0.26 while it runs and is billed only for the miners whose answers are used.
- `telegraph_ask_miner` is a miner call: one miner you choose, with a question or one of its endpoints, at that miner's price.
- All three are paid by the account: from its escrow balance by default, or with x402 from its Solana address (`payment: "solana"`; every account has one, funded from the Wallet menu in Anjoman) or its EVM address (`payment: "evm"`, wallet-connected accounts only). `TELEGRAPH_KEY_PAYMENT` sets the default. Paid on Solana, `telegraph_ask_auto` goes without the budget: one miner answers.
- `telegraph_account` shows the account's escrow balance and what its last jobs cost. Top up in Anjoman: this server cannot deposit.
- `telegraph_deposit` is not offered: a key cannot move funds.
- The free tools (`telegraph_find_intents`, `telegraph_intent`, `telegraph_find_miners`, `telegraph_ranking`, `telegraph_docs`) work as before.
- The wallet, `TELEGRAPH_PAYMENT` and the per-ask and daily limits do not apply. The account's balance and the key's own limits (30 requests a minute, an optional expiry) do. Revoke the key in Anjoman to cut off an agent at once.

Treat the key like a password: it can spend your balance. Keep it in an agent's settings, not in a repository.

## Tools

| Tool | Cost | What it does |
|---|---|---|
| `telegraph_ask` | ~$0.01 per miner used | Ask a question, optionally with an exact intent and params. The node routes it to the top live miner, and asks the next ones for what it missed |
| `telegraph_ask_miner` | the miner's price | Miner call: ask one miner you choose, or call one of its endpoints directly |
| `telegraph_ask_auto` | ~$0.01 per miner used | API key only: the node's auto-routed ask, without Anjoman's agent |
| `telegraph_find_intents` | free | Search the 130+ intents (kinds of question) |
| `telegraph_intent` | free | One intent's kind, params, answer fields and top miners |
| `telegraph_find_miners` | free | An intent's miners with rank, score, price and endpoints, or a word search over all miners |
| `telegraph_ranking` | free | The latest epoch's ranking, per intent |
| `telegraph_account` | free | Address, network, wallet and escrow balances, limits, spending today, and how to top up |
| `telegraph_docs` | free | Built-in guides, also served as MCP resources (`telegraph://docs/...`) |
| `telegraph_deposit` | gas | Only with `TELEGRAPH_ALLOW_AGENT_DEPOSIT`: move wallet USDC into escrow |

## Test funds (testnet)

The testnet runs on Ethereum Sepolia, so there's no real money. Its USDC (`0xcc194e1a843B658526D0D5C431f670028582Ae17`) is Telegraph's own test token, not Circle's: the escrow takes that one and no other, and `telegraph_account` names it. Claim it at [anjoman.ai/dashboard/faucet](https://anjoman.ai/dashboard/faucet) (sign in) and send it to your Telegraph wallet, or mint it directly (`mint(address,uint256)`, anyone can). `fund` points you there. Gas needs a little Sepolia ETH from a public faucet. Balances in the previous diamond (`0x3624…b99b`) do not carry over.

## Security

- The key lives in `~/.telegraph/wallet.json` (mode 0600), or in `TELEGRAPH_PRIVATE_KEY` if you set one. It's never in an agent's config, a tool result or a log, so the agent and its model never see it through MCP.
- Use a wallet made for this, holding only what you plan to spend. The limits cap what the agent can spend.
- By default the agent gets no tool that moves funds: deposits and withdrawals happen in your terminal, after you confirm.
- That holds for the tools. An agent that can also run shell commands (Claude Code, Cursor, Goose) can read the wallet file or run `fund` itself, so the real protection is the dedicated wallet and the limits, not the tool list.
- The server runs locally over stdio and opens no port.

## Development

```bash
npm install && npm run build && npm test
node scripts/smoke.mjs                                       # free tools against the node
node scripts/smoke.mjs paid                                  # plus three asks (~$0.03), using the setup wallet
node scripts/smoke.mjs call telegraph_intent '{"intent":"CRYPTO_PRICE_USD"}'
npx @modelcontextprotocol/inspector dist/index.js            # browse the tools
```

Architecture: [docs/architecture.md](docs/architecture.md). Problems: [docs/troubleshooting.md](docs/troubleshooting.md).
